## Contributing

- Fork it ( https://github.com/adhiariyadi/Sistem-Informasi-Akademik-Sekolah-Laravel/fork )
- Create your feature branch (`git checkout -b my-new-feature`)
- Commit your changes (`git commit -am 'Add some feature'`)
- Push to the branch (`git push origin my-new-feature`)
- Create a new Pull Request
