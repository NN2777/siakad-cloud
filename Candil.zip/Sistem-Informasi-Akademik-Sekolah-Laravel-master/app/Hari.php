<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Hari extends Model
{
    protected $fillable = ['nama_hari'];

    protected $table = 'hari';
}
